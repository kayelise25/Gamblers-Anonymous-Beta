#imports
import random

#Global Variables
player_total = 0
dealer_total = 0
player_wins = 0
player_loses = 0

#Making the  deck 
card_values = {
    'A': 11,
    'K': 10,
    'Q': 10,
    'J': 10,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7,
    '8': 8,
    '9': 9,
    '10': 10
}
hand = []
fullDecks = []
    

def make_hands(numDecks):
    for i in range(numDecks):
        for k in card_values:
            for y in range(4):
                fullDecks.append(card_values[k]) 
    return fullDecks



#hit function
def hit(card):
    global player_total
    print("the current hand total:",player_total)
    if ((player_total + int(card)) > 21 and int(card) == 11):
        player_total += 1 
    else:
        player_total += card
     
     #Debug
    print('HIT ---- player total:',player_total, '  dealer card:',dealer_total)

def stand():
     #Debug
    print('STAND ---- player total:',player_total, '  dealer card:',dealer_total)
    

def doubleDown(card):
    global player_total
    global bonus
    if (player_total + card > 21 and card == 11):
        player_total += 1
    else:
        player_total += card
    bonus = 1

     #Debug
    print('DD ---- player total:',player_total, '  dealer card:',dealer_total)

def split(card1, card2, cards):
    #Variables
    global player_total
    global player_wins
    global player_loses
    hand1_total = 0
    hand2_total = 0
    Dealer_total = 0
    next_card = 4
    # check to see of the first two cards are the same number
    if (cards[0] == cards[2]):
        # if they are split into two players
        hand1_total += card1
        hand2_total += card2
        # player 1 hits cards till 17 or bust
        while(hand1_total < 17):
            hand1_total += cards[next_card]
            next_card += 1
        # player 2 hits cards till 17 or bust
        while(hand2_total < 17):
            hand2_total += cards[next_card]
            next_card += 1 
        #give dealer cards till 17 or bust
        while(dealer_total < 17):
            dealer_total += cards[next_card]
            next_card += 1  
    # hand #1 
    if hand1_total > 21:
        player_loses +=1
    elif hand1_total < dealer_total and dealer_total <= 21:
        player_loses +=1
    elif dealer_total > 21:
        player_wins +=1
    elif dealer_total < hand1_total and hand1_total <= 21:
        player_wins +=1
 

    #hand  #2
    if hand2_total > 21:
        player_loses +=1
    elif hand2_total < dealer_total and dealer_total <= 21:
        player_loses +=1
    elif dealer_total > 21:
        player_wins +=1
    elif dealer_total < hand2_total and hand2_total <= 21:
        player_wins +=1
     
     #Debug
    print('SPLIT ---- player total:',player_total, '  dealer card:',dealer_total)

def checkWinLose(bonus = 0):
    global player_wins
    global player_loses

    if dealer_total > 21 or player_total == 21:
        player_wins += 1
        player_wins += bonus
    elif player_total > 21 or dealer_total > player_total:
        player_loses += 1
    elif player_total > dealer_total:
        player_wins += 1
        player_wins += bonus

#main gameplay code
def play_game(strategyCard):
    global player_total
    global dealer_total
    player_card1 = 0
    player_card2 = 0 
    canSplit = True
    pair = False
    Ace = False
    run_game = True

    numDecks = int(input("How many Decks do you want: "))
    all_Cards = make_hands(numDecks)
    
    current_hand = random.sample(all_Cards,20)
    next_card = 0

#giving the first 3 cards
    player_total += current_hand[next_card]
    player_card1 = current_hand[next_card]
    next_card+=1
    
    dealer_total += current_hand[next_card]
    next_card+=1

    player_total += current_hand[next_card]
    player_card2 = current_hand[next_card]
    next_card+=1

    
    while(run_game):
        global bonus
        bonus = 0
        #checking for Pair 
        if(player_card1 == player_card2):
            pair = True

        #check for Ace
        if(player_card1 == 11 or player_card2 == 11):
            Ace = True
        #Debug
        print('card 1:',player_card1,'  card 2:',player_card2, 'player total:',player_total, '  dealer card:',dealer_total)
        

        #appling strategy for non pairs
        if(pair == False and Ace == False):
            #debug
            print("Current No Pair/Ace strategy:", strategyCard[player_total-8][dealer_total-2])

            if(player_total >= 17 and player_total < 21):
                stand()
                next_card+=1
                run_game = False
            elif(strategyCard[player_total-8][dealer_total-2] == 'H'):
                hit(current_hand[next_card])
                next_card+=1
            elif(strategyCard[player_total-8][dealer_total-2] == 'D'):
                doubleDown(current_hand[next_card])
                next_card+=1
                run_game = False
            elif(strategyCard[player_total-8][dealer_total-2] == 'S'):
                stand()
                next_card+=1
                run_game = False
            elif(strategyCard[player_total-8][dealer_total-2] == 'P' and canSplit):
                split(player_card1, player_card2)
                canSplit = False
                next_card+=1

        #applying strategy to pairs
        if(pair == True and Ace == False):
            #debug
            print("Current Pair, No Ace strategy:", strategyCard[player_total+6][dealer_total-2])

            if(player_total >= 17 and player_total < 21):
                stand()
                next_card+=1
                run_game = False
            elif(strategyCard[player_total+6][dealer_total-2] == 'H'):
                hit(current_hand[next_card])
                next_card+=1
            elif(strategyCard[player_total+6][dealer_total-2] == 'D'):
                doubleDown(current_hand[next_card])
                next_card+=1
                run_game = False
            elif(strategyCard[player_total +6][dealer_total-2] == 'S'):
                stand()
                next_card+=1
                run_game = False
            elif(strategyCard[player_total + 6][dealer_total-2] == 'P' and canSplit):
                split(player_card1, player_card2)
                canSplit = False
                next_card+=1

        #applying strategy to Aces combo
        if(pair == False and Ace == True):
            #debug
            print("Current Ace present strategy:", strategyCard[player_total+7][dealer_total-2])
            if(strategyCard[player_total+6][dealer_total-2] == 'H'):
                hit(current_hand[next_card])
                next_card+=1
            elif(strategyCard[player_total+6][dealer_total-2] == 'D'):
                doubleDown(current_hand[next_card])
                next_card+=1
                run_game = False
            elif(strategyCard[player_total+6][dealer_total-2] == 'S'):
                stand()
                next_card+=1
                run_game = False
            elif(strategyCard[player_total+6][dealer_total-2] == 'P' and canSplit):
                split(player_card1, player_card2)
                canSplit = False
                next_card+=1
            
            #applying strategy to pair pf aces
            if(player_card1 == 11 and player_card2 == 11 and canSplit):
                split(player_card1, player_card2)
                canSplit = False
                next_card+=1

        #checking if the game should end/player busts
        if(player_total >= 21):
            run_game = False
    #Play dealer
    while(dealer_total < 17 and player_total < 21):
        dealer_total += current_hand[next_card]
    
    #check if player wins
    checkWinLose(bonus)

    #Debug
    print('player total:',player_total, '  dealer card:',dealer_total)

def main():
    H = 'H'
    D = 'D'
    S = 'S'
    P = "P"
    strategyCard = [
        [H, H, H, H, H, H, H, H, H, H], #[0]
        [H, D, D, D, D, H, H, H, H, H],
        [D, D, D, D, D, D, D, D, H, H],
        [D, D, D, D, D, D, D, D, D, H],
        [H, H, S, S, S, H, H, H, H, H],
        [H, H, S, S, S, H, H, H, H, H],#[5]
        [S, S, S, S, S, H, H, H, H, H],
        [S, S, S, S, S, H, H, H, H, H],
        [S, S, S, S, S, H, H, H, H, H],
        [S, S, S, S, S, S, S, S, S, S], #17
        [H, H, P, P, P, P, H, H, H, H], #Pairs [10][y]
        [H, H, P, P, P, P, H, H, H, H],
        [H, H, H, H, H, H, H, H, H, H],
        [D, D, D, D, D, D, D, D, H, H],
        [H, P, P, P, P, H, H, H, H, H],
        [P, P, P, P, P, P, H, H, H, H],#[15]
        [P, P, P, P, P, P, P, P, P, P],
        [P, P, P, P, P, S, P, P, S, S],
        [S, S, S, S, S, S, S, S, S, S],
        [P, P, P, P, P, P, P, P, P, P],#Aces [19][y]
        [H, H, H, D, D, H, H, H, H, H],#[20]
        [H, H, H, D, D, H, H, H, H, H],
        [H, H, D, D, D, H, H, H, H, H],
        [H, H, D, D, D, H, H, H, H, H],
        [H, D, D, D, D, H, H, H, H, H],
        [S, D, D, D, D, H, H, H, H, H],#[25]
        [S, S, S, S, S, S, S, S, S, S],
        [S, S, S, S, S, S, S, S, S, S],
        [S, S, S, S, S, S, S, S, S, S] #[28]
    ]
 
    play_game(strategyCard)
    print("player wins:", player_wins, '  player loses:', player_loses)

#running the code
if __name__ == "__main__":
   main()