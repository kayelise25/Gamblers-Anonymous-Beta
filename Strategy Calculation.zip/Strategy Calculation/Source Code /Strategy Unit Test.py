import unittest
import hands


class MyTestCase(unittest.TestCase):
    def test_is_split(self):
        self.assertEqual(hands.is_split(("4H", 4), ("4H", 4)), True)

    def test_is_double_down(self):
        self.assertEqual(hands.is_a_DoubleDown(("4H", 4), ("4H", 4)), False)



    def test_stand(self):
        self.assertEqual(hands.stand_down_scenario(("QH", 10), ("QH", 10), ("5D", 5),
                                                  {"7H": 7, "5C": 5, "5H": 5, "3C": 3, "JD": 10, "4S": 4, "JC": 10,
                                                   "5D": 5,
                                                   "QC": 10, "9C": 9, "8D": 8, "AH": 11, "QS": 10, "6D": 6, "QD": 10,
                                                   "KD": 10,
                                                   "3D": 3, "AS": 11}), 1)

    def test_split(self):
        self.assertEqual(hands.split_scenario(("QH", 10), ("QH", 10), ("5D", 5),
                                             {"7H": 7, "5C": 5, "5H": 5, "3C": 3, "JD": 10, "4S": 4, "JC": 10, "5D": 5,
                                              "QC": 10, "9C": 9, "8D": 8, "AH": 11, "QS": 10, "6D": 6, "QD": 10,
                                              "3D": 3, "AS": 11}), 2)

    def test_down(self):
        self.assertEqual(hands.double_down_scenario(("QH", 10), ("4H", 4), ("5D", 5),
                                                   {"7H": 7, "5C": 5, "5H": 5, "3C": 3, "JD": 10, "4S": 4, "JC": 10,
                                                    "5D": 5,
                                                    "QC": 10, "9C": 9, "8D": 8, "AH": 11, "QS": 10, "6D": 6, "QD": 10,
                                                    "KD": 10,
                                                    "3D": 3, "AS": 11}), 0)

    def test_IsAce(self):
        self.assertEqual(hands.is_Ace(("AS", 11)), True)

    def test_FindPlayerPair(self):
        self.assertEqual(hands.FindPlayerPair(("QH", 10)), 18)

    def test_FindTheCombo(self):
        self.assertEqual(hands.FindTheACombo(("QH", 10), ("QH", 10)), None)

   # def test_AisPresent(self):
   #     self.assertEqual(hands.a_is_present("AS", 10), 21)

    def test_hitScenario(self):
        self.assertEqual(hands.hit_scenario(("QH", 10), ("QH", 10), ("5D", 5),
                                            {"7H": 7, "5C": 5, "5H": 5, "3C": 3, "JD": 10, "4S": 4, "JC": 10,
                                            "5D": 5,
                                             "QC": 10, "9C": 9, "8D": 8, "AH": 11, "QS": 10, "6D": 6, "QD": 10,
                                             "KD": 10,
                                             "3D": 3, "AS": 11}), 1)

    def test_FindDealerIndex(self):
        self.assertEqual(hands.FindDealerIndex(("AS", 10)), 9)

    def test_FindPlayerIndex(self):
        self.assertEqual(hands.FindPlayerIndex(("AS", 10), ("5D", 5)), 23)

if __name__ == '__main__':
    unittest.main()