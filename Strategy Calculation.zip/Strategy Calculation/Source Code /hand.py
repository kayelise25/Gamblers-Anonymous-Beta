import random
import json
import pprint
import pandas as pd

#NOTE I COMMENTED OUT EXCEL FEATURE

# Add up all wins then divide by one million
# Make the number of hands an option
# Standard values of cards
card_values = {
    'A': 11,
    'K': 10,
    'Q': 10,
    'J': 10,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7,
    '8': 8,
    '9': 9,
    '10': 10
}

'''
loop through card values putting to create deck
 H = Hearts
 S = Spades
 D = Diamonds
 C = Clubs
'''

deck_of_cards = {}
for i in card_values:
    for k in range(4):
        deck_of_cards[f"{i}H"] = card_values[i]
        deck_of_cards[f"{i}S"] = card_values[i]
        deck_of_cards[f"{i}D"] = card_values[i]
        deck_of_cards[f"{i}C"] = card_values[i]

# Ask User How many decks they want. User inputs number, x.
num_of_decks = input("How many decks would you like?: ")

# To make sure the user only types in a number
while not num_of_decks.isdigit():
    num_of_decks = input("Must be num like 1 2 3. Enter again: ")

num_of_decks = int(num_of_decks)

# Loop X times. Create a list that has X deck of cards
bag_of_decks = []
for x in range(num_of_decks):
    bag_of_decks.append(deck_of_cards)

# For the frequency table make an array for potential player and dealer cards
dealer_cards = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'A']
player_cards = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
                '(2, 2)', '(3, 3)', '(4, 4)', '(5, 5)', '(6, 6)', '(7, 7)', '(8, 8)', '(9, 9)', '(10, 10)', '(A, A)',
                '(A, 2)', '(A, 3)', '(A, 4)', '(A, 5)', '(A, 6)', '(A, 7)', '(A, 8)', '(A, 9)', '(A, 10)']

# Frequency Table
fr = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      ]

# Double Down Table
double_down_table = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                     ]

# Stand Table
stand_table = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               ]

# Split Table
split_table = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
               ]

# Hit Table
hit_table = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             ]


# Check if there are duplicate player cards
def FindPlayerPair(pone, ptwo):
    # If you find a duplicate such as (2, 2) then hardcode it into its spot
    if pone[1] == 2:
        return 10
    elif pone[1] == 3:
        return 11
    elif pone[1] == 4:
        return 12
    elif pone[1] == 5:
        return 13
    elif pone[1] == 6:
        return 14
    elif pone[1] == 7:
        return 15
    elif pone[1] == 8:
        return 16
    elif pone[1] == 9:
        return 17
    elif pone[1] == 10 and pone[0][0] == ptwo[0][0]:
        if pone[0][0] != 'A':
            return 18
    else:
        return 19


# In this function, you are looking for (A, 2), (A, 3), (A, 4)....
def FindTheACombo(pone, ptwo):
    if pone[0][0] == 'A':
        if ptwo[1] == 2:
            return 20
        elif ptwo[0][0] == 'A':
            return 19
        elif ptwo[1] == 3:
            return 21
        elif ptwo[1] == 4:
            return 22
        elif ptwo[1] == 5:
            return 23
        elif ptwo[1] == 6:
            return 24
        elif ptwo[1] == 7:
            return 25
        elif ptwo[1] == 8:
            return 26
        elif ptwo[1] == 9:
            return 27
        else:
            return 28
    if ptwo[0][0] == 'A':
        if pone[1] == 2:
            return 20
        elif pone[0][0] == 'A':
            return 19
        elif pone[1] == 3:
            return 21
        elif pone[1] == 4:
            return 22
        elif pone[1] == 5:
            return 23
        elif pone[1] == 6:
            return 24
        elif pone[1] == 7:
            return 25
        elif pone[1] == 8:
            return 26
        elif pone[1] == 9:
            return 27
        else:
            return 28


# Locate the player index for the y axis
def FindPlayerIndex(pone, ptwo):
    # If the player cards are the same value, return the respective pair
    if pone[1] == ptwo[1] and pone[0][0] == ptwo[0][0]:
        if pone[0][0] == 'A' or ptwo[0][0] == 'A':
            return FindTheACombo(pone, ptwo)
        return FindPlayerPair(pone, ptwo)
    # If the sum of player cards is less than 8, put into the assign 0 index
    elif pone[1] + ptwo[1] < 8:
        return 0
    # If at least one player card is an ace, return the respective ace combo
    elif pone[0][0] == 'A' or ptwo[0][0] == 'A':
        return FindTheACombo(pone, ptwo)
    # This is a regular case with no A combo or pair
    else:
        ind = pone[1] + ptwo[1]
        for indice in range(0, len(player_cards)):
            if player_cards[indice] == ind:
                return indice
        return 9


# Iterate through dealer cards array to find the right x axis
def FindDealerIndex(current_dealer_card):
    for index in range(len(dealer_cards)):
        if dealer_cards[index] == current_dealer_card[1] and current_dealer_card[0][0] != 'A':
            return index
    # The card made it through the loop w/o returning anything then it must be A
    return 9


# Locate the corresponding value to increment in
def assignToTable(dcards, pone, ptwo):
    # Get the player and dealer indices
    player_ind = FindPlayerIndex(pone, ptwo)
    dealer_ind = FindDealerIndex(dcards)
    # Increment the frequency table and return the indices to use in other tables
    fr[player_ind][dealer_ind] += 1
    return player_ind, dealer_ind


# Method created keeps a running total of each hand accounted for in the main function
def getTotal():
    summ = 0
    for curr_list in fr:
        for curr_val in curr_list:
            summ += curr_val
    print(summ)


# Import to frequency table to excel
def importToExcel():
    # Create the data frame where the player card combo is the y axis and the x axis is the dealer cards. Repeat for
    # each table
    date_frame = pd.DataFrame(fr, columns=dealer_cards, index=player_cards)
    # Create excel writer object
    writer = pd.ExcelWriter('FrequencyTable.xlsx', engine='xlsxwriter')
    # Add frequency table to excel in this format
    date_frame.to_excel(writer, sheet_name='my sheet', startcol=0, startrow=0)
    writer.close()

    # Send Double down table to Excel
    date_frame = pd.DataFrame(double_down_table, columns=dealer_cards, index=player_cards)
    writer = pd.ExcelWriter('DoubleTableWinPercentage.xlsx', engine='xlsxwriter')
    date_frame.to_excel(writer, sheet_name='my sheet', startcol=0, startrow=0)
    writer.close()

    # Send Stand table to Excel
    date_frame = pd.DataFrame(stand_table, columns=dealer_cards, index=player_cards)
    writer = pd.ExcelWriter('StandTableWinPercentage.xlsx', engine='xlsxwriter')
    date_frame.to_excel(writer, sheet_name='my sheet', startcol=0, startrow=0)
    writer.close()

    # Send Split table to Excel
    date_frame = pd.DataFrame(split_table, columns=dealer_cards, index=player_cards)
    writer = pd.ExcelWriter('SplitTableWinPercentage.xlsx', engine='xlsxwriter')
    date_frame.to_excel(writer, sheet_name='my sheet', startcol=0, startrow=0)
    writer.close()

    # Send Hit table to Excel
    date_frame = pd.DataFrame(hit_table, columns=dealer_cards, index=player_cards)
    writer = pd.ExcelWriter('HitTableWinPercentage.xlsx', engine='xlsxwriter')
    date_frame.to_excel(writer, sheet_name='my sheet', startcol=0, startrow=0)
    writer.close()


# Loop though table and switch the values to wins/occurences
def loopThroughMatrix(mat):
    for i in range(len(mat)):
        for k in range(len(mat[i])):
            # DD[currentIndex] = Wins/Occurence
            if mat[i][k] != 0:
                mat[i][k] = float(mat[i][k] / fr[i][k])


def is_Ace(card_one):
    return card_one[0][0] == 'A'


def a_is_present(card_one, total):
    if total + card_one[1] > 21:
        return total + 1
    return total + 11


# Check if the current state is a double down state
def is_a_DoubleDown(card_one, card_two):
    # Check if the player combo matches with any of the double down pairs
    player_sum = 0
    if is_Ace(card_one):
        player_sum += a_is_present(card_one, player_sum)
    else:
        player_sum += card_one[1]
    if is_Ace(card_two):
        player_sum += a_is_present(card_two, player_sum)
    else:
        player_sum += card_two[1]
    # For split pair and A combo case
    player_combo = (card_one[0][0], card_two[0][0])
    if 9 <= player_sum <= 11:
        return True
    elif card_one[1] == 5 and card_two[1] == 5:
        return True
    elif player_combo == ('A', 'A'):
        return True
    elif player_combo == ('A', '2') or player_combo == ('2', 'A'):
        return True
    elif player_combo == ('A', '3') or player_combo == ('3', 'A'):
        return True
    elif player_combo == ('A', '4') or player_combo == ('4', 'A'):
        return True
    elif player_combo == ('A', '5') or player_combo == ('5', 'A'):
        return True
    elif player_combo == ('A', '6') or player_combo == ('6', 'A'):
        return True
    elif player_combo == ('A', '7') or player_combo == ('7', 'A'):
        return True
    elif player_combo == ('A', '8') or player_combo == ('8', 'A'):
        return True
    elif player_combo == ('A', '9') or player_combo == ('9', 'A'):
        return True
    elif player_combo == ('A', '10') or player_combo == ('10', 'A'):
        return True
    elif (card_two[0][0] == 'A' and (card_one[1] == 10 and card_one[0][0] != 'A')) or (
            card_one[0][0] == 'A' and (card_two[1] == 10 and card_two[0][0] != 'A')):
        return True
    else:
        return False


# Run the double down scenario for the current state
def double_down_scenario(pc_one, pc_two, dc_one, the_current_hand):
    # Take out a new card and add it to the player's total
    new_card = the_current_hand.popitem()
    ptotal = 0
    dtotal = 0
    if is_Ace(pc_one):
        ptotal = a_is_present(pc_one, ptotal)
    else:
        ptotal += pc_one[1]
    if is_Ace(pc_two):
        ptotal = a_is_present(pc_two, ptotal)
    else:
        ptotal += pc_two[1]
    if is_Ace(new_card):
        ptotal = a_is_present(new_card, ptotal)
    else:
        ptotal += new_card[1]
    if is_Ace(dc_one):
        dtotal = a_is_present(dc_one, dtotal)
    else:
        dtotal += dc_one[1]
    if ptotal > 21:
        return 0
    # The dealer keeps playing till they cannot
    while dtotal < 17:
        nc = the_current_hand.popitem()
        if nc[0][0] == 'A':
            dtotal = a_is_present(nc, dtotal)
        else:
            dtotal += nc[1]
    # If the dealer busts
    if dtotal > 21 or ptotal > dtotal:
        return 1
    return 0


# Determine if the current combination is a split
def is_split(card_one, card_two):
    # They can't be a split if they arent the same
    if card_one[1] != card_two[1]:
        return False
    if card_one[1] == 2:
        return True
    elif card_one[1] == 3:
        return True
    elif card_one[1] == 4:
        return True
    elif card_one[1] == 5:
        return True
    elif card_one[1] == 6:
        return True
    elif card_one[1] == 7:
        return True
    elif card_one[1] == 8:
        return True
    elif card_one[1] == 9:
        return True
    elif card_one[0][0] == 'A' and card_two[0][0] == 'A':
        return True
    elif card_one[1] == 10 and (card_one[0][0] == card_two[0][0]):
        return True
    return False


# Run the split scenario and return whether or not they won
def split_scenario(pc_one, pc_two, dc_one, the_current_hand):
    pTotalOne = 0
    pTotalTwo = 0
    dTotal = dc_one[1]
    if is_Ace(pc_one):
        pTotalOne = a_is_present(pc_one, pTotalOne)
        pTotalTwo = a_is_present(pc_two, pTotalTwo)
    else:
        pTotalOne += pc_one[1]
        pTotalTwo += pc_two[1]
    if is_Ace(dc_one):
        dTotal = a_is_present(dc_one, dTotal)
    else:
        dTotal += dc_one[1]

    while pTotalOne < 17:
        nc = the_current_hand.popitem()
        if is_Ace(nc):
            pTotalOne = a_is_present(nc, pTotalOne)
        else:
            pTotalOne += nc[1]
    while pTotalTwo < 17:
        nc = the_current_hand.popitem()
        if is_Ace(nc):
            pTotalTwo = a_is_present(nc, pTotalTwo)
        else:
            pTotalTwo += nc[1]
    if pTotalOne > 21 and pTotalTwo > 21:
        return 0
    while dTotal < 17:
        nc = the_current_hand.popitem()
        if is_Ace(nc):
            dTotal = a_is_present(nc, dTotal)
        else:
            dTotal += nc[1]
    if dTotal > 21 or (pTotalOne > dTotal and pTotalTwo > dTotal):
        return 2
    if pTotalOne > dTotal or pTotalTwo > dTotal:
        return 1
    if pTotalOne < dTotal <= 21 and pTotalTwo < dTotal <= 21:
        return 0
    return 0


# Check to see if the state is a stand down state
def is_stand_down(card_one, card_two):
    # Check if the player combo matches with any of the double down pairs
    player_sum = 0
    if is_Ace(card_one):
        player_sum += a_is_present(card_one, player_sum)
    else:
        player_sum += card_one[1]
    if is_Ace(card_two):
        player_sum += a_is_present(card_two, player_sum)
    else:
        player_sum += card_two[1]
    # For split pair and A combo case
    player_combo = (card_one[0][0], card_two[0][0])
    if 12 <= player_sum <= 17 and (card_one[0][0] != 'A' and card_two[0][0] != 'A'):
        return True
    elif card_one[1] == 9 and card_two[1] == 9:
        return True
    elif player_combo == ('A', '6') or player_combo == ('6', 'A'):
        return True
    elif player_combo == ('6', '6') or player_combo == ('6', '6'):
        return True
    elif player_combo == ('A', '7') or player_combo == ('7', 'A'):
        return True
    elif player_combo == ('A', '8') or player_combo == ('8', 'A'):
        return True
    elif player_combo == ('A', '9') or player_combo == ('9', 'A'):
        return True
    elif player_combo == ('A', '10') or player_combo == ('10', 'A'):
        return True
    elif (card_two[0][0] == 'A' and (card_one[1] == 10 and card_one[0][0] != 'A')) or (
            card_one[0][0] == 'A' and (card_two[1] == 10 and card_two[0][0] != 'A')):
        return True
    elif (card_one[1] == 10 and card_two[1] == 10) and (card_one != 'A' and card_two != 'A'):
        return True
    else:
        return False


# If in stand down state, run stand down scenario
def stand_down_scenario(pc_one, pc_two, dc_one, the_current_hand):
    #
    pc_total = 0
    dc_total = 0
    if is_Ace(pc_one):
        pc_total = a_is_present(pc_one, pc_total)
    else:
        pc_total += pc_one[1]
    if is_Ace(pc_two):
        pc_total = a_is_present(pc_two, pc_total)
    else:
        pc_total += pc_two[1]
    if is_Ace(dc_one):
        dc_total = a_is_present(dc_one, dc_total)
    else:
        dc_total += dc_one[1]
    if pc_total > 21:
        return 0
    while dc_total < 17 and pc_total > dc_total:
        d = the_current_hand.popitem()
        if is_Ace(d):
            dc_total = a_is_present(d, dc_total)
        else:
            dc_total += d[1]
    if dc_total > 21:
        return 1

    if pc_total > dc_total:
        return 1

    return 0


def hit_scenario(pc_one, pc_two, dc_one, the_current_hand):
    player_sum = 0
    dealer_total = 0
    if is_Ace(pc_one):
        player_sum = a_is_present(pc_one, player_sum)
    else:
        player_sum += pc_one[1]
    if is_Ace(pc_two):
        player_sum = a_is_present(pc_two, player_sum)
    else:
        player_sum += pc_two[1]
    if is_Ace(dc_one):
        dealer_total = a_is_present(dc_one, dealer_total)
    else:
        dealer_total += dc_one[1]
    while player_sum < 17:
        nc = the_current_hand.popitem()
        if is_Ace(nc):
            player_sum = a_is_present(nc, player_sum)
        else:
            player_sum += nc[1]

    if player_sum > 21:
        return 0

    while dealer_total < 17 and dealer_total < player_sum:
        nc = the_current_hand.popitem()
        if is_Ace(nc):
            dealer_total = a_is_present(nc, dealer_total)
        else:
            dealer_total += nc[1]

    if dealer_total > 21 or dealer_total < player_sum:
        return  1
    elif player_sum < dealer_total:
        return 0
    elif dealer_total == player_sum:
        return 0
    return 0


def printTheMatrix(arr):
    for i in range(len(arr)):
        print("")
        for k in range(len(arr[i])):
            # DD[currentIndex] = Wins/Occurence
            print(f'{arr[k]},', end="")


file = open('hands.txt', 'w')
how_many_hands = input("How many hands would you like?: ")

# To make sure the user only types in a number
while not how_many_hands.isdigit():
    how_many_hands = input("Must be num like 1 2 3. Enter again: ")

how_many_hands = int(how_many_hands)
for j in range(0, how_many_hands):
    # I made three extra copies of the current hand for the scenarios
    curr_hand = {}
    curr_hand_two = {}
    curr_hand_three = {}
    curr_hand_four = {}
    for i in range(20):
        # Pick a random deck
        random_deck = random.choice(bag_of_decks)
        # From random deck, pick a random card
        card, its_value = random.choice(list(random_deck.items()))
        # Put that card in the current hand
        curr_hand[card] = its_value
        curr_hand_two[card] = its_value
        curr_hand_three[card] = its_value
        curr_hand_four[card] = its_value
    # Store in the file json style
    file.write(f"Hand {j + 1}: {json.dumps(curr_hand)}\n")
    # Take out the first three cards
    player_card_one = curr_hand.popitem()
    dealer_card_one = curr_hand.popitem()
    player_card_two = curr_hand.popitem()

    curr_hand_two.popitem()
    curr_hand_two.popitem()
    curr_hand_two.popitem()

    curr_hand_three.popitem()
    curr_hand_three.popitem()
    curr_hand_three.popitem()

    curr_hand_four.popitem()
    curr_hand_four.popitem()
    curr_hand_four.popitem()

    # Add to the frequency table whichever combo was found
    indexes = assignToTable(dealer_card_one, player_card_one, player_card_two)

    # check if they won the hit scenario
    hit_table[indexes[0]][indexes[1]] += hit_scenario(player_card_one, player_card_two, dealer_card_one,
                                                      curr_hand_four)
    # Check if the combination is a split
    if is_split(player_card_one, player_card_two):
        # Check if they won and increment based off the win
        split_table[indexes[0]][indexes[1]] += split_scenario(player_card_one, player_card_two, dealer_card_one,
                                                              curr_hand_two)
    # Check if the combination is a double down
    if is_a_DoubleDown(player_card_one, player_card_two):
        # Check if they won
        double_down_table[indexes[0]][indexes[1]] += double_down_scenario(player_card_one, player_card_two,
                                                                          dealer_card_one, curr_hand_three)
    # Check if the combination is a stand
    if is_stand_down(player_card_one, player_card_two):
        # check if they won
        stand_table[indexes[0]][indexes[1]] += stand_down_scenario(player_card_one, player_card_two, dealer_card_one,
                                                                   curr_hand)

# Print out the double down table in proper format
# Loop though double down table and switch the values to wins/occurences
loopThroughMatrix(double_down_table)
print("\nDouble Down Table Probability")
pprint.pprint(double_down_table)

# Print out the Stand table in proper format
# Loop though stand table and switch the values to wins/occurences
loopThroughMatrix(stand_table)
# Print out the Stand table in proper format
print("\nStand Table Probability")
pprint.pprint(stand_table)

# Print out the Split table in proper format
# Loop though split table and switch the values to wins/occurences
loopThroughMatrix(split_table)
# Print out the Split table in proper format
print("\nSplit Table Probability")
pprint.pprint(split_table)

# Print out the hit table in proper format
# Loop though hit table and switch the values to wins/occurences
loopThroughMatrix(hit_table)
# Print out the hit table in proper format
print("\nHit Table Probability")
pprint.pprint(hit_table)

# Print out the frequency table in proper format
print("\nFrequency Table")
pprint.pprint(fr)

# Get the total number of hands accounted for
getTotal()
# Close the text
file.close()
# Import Tables to excel
importToExcel()
